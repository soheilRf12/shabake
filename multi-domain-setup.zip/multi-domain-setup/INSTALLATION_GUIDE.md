# راهنمای نصب و راه‌اندازی سیستم چند دامنه

## پیش‌نیازها

- Ubuntu (18.04 یا بالاتر) - **Server یا Desktop**
  - ✅ Ubuntu Server - پشتیبانی کامل
  - ✅ Ubuntu Desktop - پشتیبانی کامل (برای راهنمای کامل به `UBUNTU_DESKTOP_GUIDE.md` مراجعه کنید)
- دسترسی root یا sudo
- حداقل 2GB RAM و 10GB فضای دیسک
- دامنه‌های ثبت شده (یا استفاده از `/etc/hosts` برای تست محلی):
  - `domain1.com`
  - `domain2.com`
  - `subdomain.domain1.com`

## مراحل نصب

### 1. آپلود فایل‌ها به سرور

فایل‌های پروژه را به سرور Ubuntu خود آپلود کنید:

```bash
# استفاده از SCP
scp -r multi-domain-setup user@your-server-ip:/home/user/

# یا استفاده از Git
git clone <repository-url>
```

### 2. اجرای اسکریپت نصب

```bash
cd multi-domain-setup
sudo bash install.sh
```

این اسکریپت به صورت خودکار:
- سیستم را به‌روزرسانی می‌کند
- Nginx و Python را نصب می‌کند
- ساختار دایرکتوری را ایجاد می‌کند
- فایل‌های کلاینت را کپی می‌کند
- پیکربندی Nginx را تنظیم می‌کند
- سرویس API را راه‌اندازی می‌کند

### 3. تنظیم DNS

در پنل مدیریت DNS خود، رکوردهای زیر را اضافه کنید:

```
A Record: domain1.com → IP سرور
A Record: www.domain1.com → IP سرور
A Record: domain2.com → IP سرور
A Record: www.domain2.com → IP سرور
A Record: subdomain.domain1.com → IP سرور
```

### 4. راه‌اندازی مجدد Nginx

```bash
sudo systemctl restart nginx
sudo systemctl status nginx
```

### 5. بررسی وضعیت سرویس‌ها

```bash
# بررسی Nginx
sudo systemctl status nginx

# بررسی API
sudo systemctl status multi-domain-api.service

# بررسی لاگ‌ها
sudo tail -f /var/log/nginx/domain1.com.access.log
sudo journalctl -u multi-domain-api.service -f
```

## ساختار سیستم

```
/var/www/
├── domain1.com/              # کلاینت دامنه اصلی 1
├── domain2.com/              # کلاینت دامنه اصلی 2
├── subdomain.domain1.com/    # کلاینت زیردامنه
├── shared_files/             # پوشه مشترک برای فایل‌ها
│   ├── domain1/
│   ├── domain2/
│   └── subdomain/
└── api/                      # API بک‌اند
```

## دسترسی‌ها

### دسترسی کلاینت زیردامنه به دامنه 2

کلاینت زیردامنه (`subdomain.domain1.com`) می‌تواند:
- فایل‌های خود را با کلاینت دامنه 2 به اشتراک بگذارد
- فایل‌های به اشتراک گذاشته شده را مشاهده کند

### نحوه استفاده

1. **آپلود فایل در زیردامنه:**
   - به `http://subdomain.domain1.com` بروید
   - فایل را آپلود کنید
   - روی دکمه "اشتراک با Domain2" کلیک کنید

2. **مشاهده فایل‌های مشترک در دامنه 2:**
   - به `http://domain2.com` بروید
   - در بخش "فایل‌های به اشتراک گذاشته شده از زیردامنه" فایل‌ها را مشاهده کنید
   - فایل‌ها را دانلود کنید

## تنظیمات پیشرفته

### تغییر پورت API

در فایل `/var/www/api/app.py`:
```python
app.run(host='0.0.0.0', port=8000, debug=False)
```

و در فایل‌های پیکربندی Nginx:
```nginx
proxy_pass http://localhost:8000/api/;
```

### تغییر محدودیت اندازه فایل

در فایل `/etc/nginx/nginx.conf`:
```nginx
client_max_body_size 100M;
```

### فعال‌سازی HTTPS

استفاده از Let's Encrypt:

```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d domain1.com -d www.domain1.com
sudo certbot --nginx -d domain2.com -d www.domain2.com
sudo certbot --nginx -d subdomain.domain1.com
```

## عیب‌یابی

### مشکل: کلاینت‌ها بارگذاری نمی‌شوند

```bash
# بررسی پیکربندی Nginx
sudo nginx -t

# بررسی لاگ‌های خطا
sudo tail -f /var/log/nginx/error.log
```

### مشکل: API کار نمی‌کند

```bash
# بررسی وضعیت سرویس
sudo systemctl status multi-domain-api.service

# بررسی لاگ‌ها
sudo journalctl -u multi-domain-api.service -n 50

# راه‌اندازی مجدد
sudo systemctl restart multi-domain-api.service
```

### مشکل: فایل‌ها آپلود نمی‌شوند

```bash
# بررسی مجوزها
sudo chown -R www-data:www-data /var/www/shared_files
sudo chmod -R 755 /var/www/shared_files

# بررسی فضای دیسک
df -h
```

## امنیت

### توصیه‌های امنیتی

1. **فایروال:**
```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

2. **تغییر مجوزها:**
```bash
sudo chmod 600 /var/www/shared_files/shared_files.json
```

3. **فعال‌سازی HTTPS** (توصیه می‌شود)

4. **محدود کردن دسترسی API:**
می‌توانید در فایل `app.py` IP های مجاز را محدود کنید.

## پشتیبانی

در صورت بروز مشکل:
1. لاگ‌های سیستم را بررسی کنید
2. وضعیت سرویس‌ها را چک کنید
3. پیکربندی‌ها را بررسی کنید

