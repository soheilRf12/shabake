#!/bin/bash

# ============================================
# اسکریپت بررسی وضعیت سیستم
# ============================================

# رنگ‌ها
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo ""
    echo -e "${GREEN}==========================================${NC}"
    echo -e "${GREEN}$1${NC}"
    echo -e "${GREEN}==========================================${NC}"
    echo ""
}

print_header "وضعیت سیستم چند دامنه"

# بررسی Nginx
echo -e "${BLUE}وضعیت Nginx:${NC}"
if systemctl is-active --quiet nginx; then
    echo -e "${GREEN}✓ Nginx در حال اجرا است${NC}"
    systemctl status nginx --no-pager -l | head -n 3
else
    echo -e "${RED}✗ Nginx در حال اجرا نیست${NC}"
fi

echo ""

# بررسی API
echo -e "${BLUE}وضعیت سرویس API:${NC}"
if systemctl is-active --quiet multi-domain-api.service; then
    echo -e "${GREEN}✓ سرویس API در حال اجرا است${NC}"
    systemctl status multi-domain-api.service --no-pager -l | head -n 3
else
    echo -e "${RED}✗ سرویس API در حال اجرا نیست${NC}"
fi

echo ""

# بررسی فایل‌ها
echo -e "${BLUE}بررسی فایل‌ها:${NC}"
if [ -d "/var/www/domain1.com" ]; then
    echo -e "${GREEN}✓ دایرکتوری domain1.com موجود است${NC}"
else
    echo -e "${RED}✗ دایرکتوری domain1.com موجود نیست${NC}"
fi

if [ -d "/var/www/domain2.com" ]; then
    echo -e "${GREEN}✓ دایرکتوری domain2.com موجود است${NC}"
else
    echo -e "${RED}✗ دایرکتوری domain2.com موجود نیست${NC}"
fi

if [ -d "/var/www/subdomain.domain1.com" ]; then
    echo -e "${GREEN}✓ دایرکتوری subdomain.domain1.com موجود است${NC}"
else
    echo -e "${RED}✗ دایرکتوری subdomain.domain1.com موجود نیست${NC}"
fi

if [ -d "/var/www/api" ]; then
    echo -e "${GREEN}✓ دایرکتوری API موجود است${NC}"
else
    echo -e "${RED}✗ دایرکتوری API موجود نیست${NC}"
fi

echo ""

# بررسی پیکربندی Nginx
echo -e "${BLUE}بررسی پیکربندی Nginx:${NC}"
if nginx -t 2>&1 | grep -q "successful"; then
    echo -e "${GREEN}✓ پیکربندی Nginx معتبر است${NC}"
else
    echo -e "${RED}✗ خطا در پیکربندی Nginx${NC}"
    nginx -t
fi

echo ""

# نمایش پورت‌های باز
echo -e "${BLUE}پورت‌های در حال استفاده:${NC}"
if command -v netstat &> /dev/null; then
    netstat -tlnp | grep -E ':(80|8000)' || echo "هیچ پورتی پیدا نشد"
elif command -v ss &> /dev/null; then
    ss -tlnp | grep -E ':(80|8000)' || echo "هیچ پورتی پیدا نشد"
else
    echo "ابزار بررسی پورت در دسترس نیست"
fi

echo ""

# نمایش آدرس‌های دسترسی
echo -e "${BLUE}آدرس‌های دسترسی:${NC}"
echo "  - http://domain1.com"
echo "  - http://domain2.com"
echo "  - http://subdomain.domain1.com"
echo ""

