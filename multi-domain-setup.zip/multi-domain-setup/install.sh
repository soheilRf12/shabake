#!/bin/bash

# اسکریپت نصب کامل سیستم چند دامنه

set -e

echo "=========================================="
echo "نصب سیستم چند دامنه"
echo "=========================================="

# بررسی دسترسی root
if [ "$EUID" -ne 0 ]; then 
    echo "لطفاً این اسکریپت را با sudo اجرا کنید"
    exit 1
fi

# به‌روزرسانی سیستم
echo "در حال به‌روزرسانی سیستم..."
apt-get update

# نصب وابستگی‌ها
echo "در حال نصب وابستگی‌ها..."
apt-get install -y nginx python3 python3-pip python3-venv

# نصب Python packages
echo "در حال نصب پکیج‌های Python..."
pip3 install Flask flask-cors Werkzeug

# اجرای اسکریپت راه‌اندازی
echo "در حال اجرای اسکریپت راه‌اندازی..."
bash setup.sh

# کپی فایل systemd service
echo "در حال تنظیم سرویس systemd..."
cp api/systemd/api.service /etc/systemd/system/multi-domain-api.service
systemctl daemon-reload
systemctl enable multi-domain-api.service
systemctl start multi-domain-api.service

# بررسی وضعیت سرویس
echo "بررسی وضعیت سرویس API..."
sleep 2
systemctl status multi-domain-api.service --no-pager

echo ""
echo "=========================================="
echo "نصب با موفقیت انجام شد!"
echo "=========================================="
echo ""
echo "مراحل بعدی:"
echo "1. تنظیم DNS برای دامنه‌ها:"
echo "   - domain1.com → IP سرور"
echo "   - domain2.com → IP سرور"
echo "   - subdomain.domain1.com → IP سرور"
echo ""
echo "2. راه‌اندازی مجدد Nginx:"
echo "   sudo systemctl restart nginx"
echo ""
echo "3. دسترسی به کلاینت‌ها:"
echo "   - http://domain1.com"
echo "   - http://domain2.com"
echo "   - http://subdomain.domain1.com"
echo ""
echo "4. بررسی وضعیت API:"
echo "   sudo systemctl status multi-domain-api.service"
echo ""

