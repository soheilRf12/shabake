#!/bin/bash

# ============================================
# اسکریپت راه‌اندازی مجدد سرویس‌ها
# ============================================

set -e

# رنگ‌ها
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# بررسی دسترسی root
if [ "$EUID" -ne 0 ]; then 
    echo "لطفاً این اسکریپت را با sudo اجرا کنید"
    exit 1
fi

echo ""
echo -e "${GREEN}==========================================${NC}"
echo -e "${GREEN}راه‌اندازی مجدد سرویس‌ها${NC}"
echo -e "${GREEN}==========================================${NC}"
echo ""

# راه‌اندازی مجدد API
print_info "راه‌اندازی مجدد سرویس API..."
systemctl restart multi-domain-api.service
sleep 2

if systemctl is-active --quiet multi-domain-api.service; then
    print_success "سرویس API راه‌اندازی شد"
else
    echo "خطا در راه‌اندازی سرویس API"
    systemctl status multi-domain-api.service --no-pager
    exit 1
fi

# راه‌اندازی مجدد Nginx
print_info "راه‌اندازی مجدد Nginx..."
systemctl restart nginx
sleep 2

if systemctl is-active --quiet nginx; then
    print_success "Nginx راه‌اندازی شد"
else
    echo "خطا در راه‌اندازی Nginx"
    systemctl status nginx --no-pager
    exit 1
fi

echo ""
print_success "تمام سرویس‌ها با موفقیت راه‌اندازی شدند"
echo ""

