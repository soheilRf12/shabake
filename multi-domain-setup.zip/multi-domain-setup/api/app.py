#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API برای مدیریت فایل‌ها و انتقال بین کلاینت‌ها
"""

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
import shutil
import json
from datetime import datetime
from werkzeug.utils import secure_filename

app = Flask(__name__)
CORS(app)

# تنظیمات
UPLOAD_FOLDER = '/var/www/shared_files'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'zip', 'rar'}

# ساختار دسترسی‌ها
# کلاینت زیردامنه می‌تواند به کلاینت دامنه 2 دسترسی داشته باشد
ACCESS_MATRIX = {
    'subdomain': ['domain2'],  # زیردامنه می‌تواند به دامنه 2 دسترسی داشته باشد
    'domain1': [],
    'domain2': []
}

# فایل برای ذخیره اطلاعات فایل‌های به اشتراک گذاشته شده
SHARED_FILES_DB = '/var/www/shared_files/shared_files.json'

def allowed_file(filename):
    """بررسی مجاز بودن پسوند فایل"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_client_folder(client_id):
    """دریافت مسیر پوشه کلاینت"""
    return os.path.join(UPLOAD_FOLDER, client_id)

def init_shared_files_db():
    """ایجاد فایل دیتابیس فایل‌های مشترک"""
    if not os.path.exists(SHARED_FILES_DB):
        with open(SHARED_FILES_DB, 'w', encoding='utf-8') as f:
            json.dump({}, f)

def load_shared_files():
    """بارگذاری اطلاعات فایل‌های مشترک"""
    init_shared_files_db()
    try:
        with open(SHARED_FILES_DB, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_shared_files(data):
    """ذخیره اطلاعات فایل‌های مشترک"""
    with open(SHARED_FILES_DB, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def check_access(from_client, to_client):
    """بررسی دسترسی بین دو کلاینت"""
    if from_client in ACCESS_MATRIX:
        return to_client in ACCESS_MATRIX[from_client]
    return False

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """آپلود فایل"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': 'فایلی ارسال نشده است'}), 400
        
        file = request.files['file']
        client_id = request.form.get('client_id')
        
        if not client_id:
            return jsonify({'success': False, 'message': 'شناسه کلاینت مشخص نشده است'}), 400
        
        if file.filename == '':
            return jsonify({'success': False, 'message': 'نام فایل خالی است'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'success': False, 'message': 'نوع فایل مجاز نیست'}), 400
        
        # ایجاد پوشه کلاینت در صورت عدم وجود
        client_folder = get_client_folder(client_id)
        os.makedirs(client_folder, exist_ok=True)
        
        # ذخیره فایل
        filename = secure_filename(file.filename)
        filepath = os.path.join(client_folder, filename)
        file.save(filepath)
        
        return jsonify({
            'success': True,
            'message': 'فایل با موفقیت آپلود شد',
            'filename': filename
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/files', methods=['GET'])
def list_files():
    """لیست فایل‌های یک کلاینت"""
    try:
        client_id = request.args.get('client_id')
        
        if not client_id:
            return jsonify({'success': False, 'message': 'شناسه کلاینت مشخص نشده است'}), 400
        
        client_folder = get_client_folder(client_id)
        
        if not os.path.exists(client_folder):
            return jsonify({'success': True, 'files': []}), 200
        
        files = []
        shared_db = load_shared_files()
        
        for filename in os.listdir(client_folder):
            filepath = os.path.join(client_folder, filename)
            if os.path.isfile(filepath):
                file_info = {
                    'name': filename,
                    'size': os.path.getsize(filepath),
                    'modified': datetime.fromtimestamp(os.path.getmtime(filepath)).isoformat(),
                    'shared': False
                }
                
                # بررسی اینکه آیا فایل به اشتراک گذاشته شده است
                for shared_info in shared_db.values():
                    if (shared_info.get('from_client') == client_id and 
                        shared_info.get('filename') == filename):
                        file_info['shared'] = True
                        file_info['shared_with'] = shared_info.get('to_client')
                        break
                
                files.append(file_info)
        
        return jsonify({'success': True, 'files': files}), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/download', methods=['GET'])
def download_file():
    """دانلود فایل"""
    try:
        client_id = request.args.get('client_id')
        filename = request.args.get('filename')
        
        if not client_id or not filename:
            return jsonify({'success': False, 'message': 'پارامترهای لازم ارسال نشده است'}), 400
        
        client_folder = get_client_folder(client_id)
        filepath = os.path.join(client_folder, secure_filename(filename))
        
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'message': 'فایل پیدا نشد'}), 404
        
        return send_file(filepath, as_attachment=True)
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/delete', methods=['POST'])
def delete_file():
    """حذف فایل"""
    try:
        data = request.get_json()
        client_id = data.get('client_id')
        filename = data.get('filename')
        
        if not client_id or not filename:
            return jsonify({'success': False, 'message': 'پارامترهای لازم ارسال نشده است'}), 400
        
        client_folder = get_client_folder(client_id)
        filepath = os.path.join(client_folder, secure_filename(filename))
        
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'message': 'فایل پیدا نشد'}), 404
        
        os.remove(filepath)
        
        # حذف از دیتابیس فایل‌های مشترک
        shared_db = load_shared_files()
        keys_to_remove = []
        for key, value in shared_db.items():
            if (value.get('from_client') == client_id and 
                value.get('filename') == filename):
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del shared_db[key]
        
        save_shared_files(shared_db)
        
        return jsonify({'success': True, 'message': 'فایل با موفقیت حذف شد'}), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/share-file', methods=['POST'])
def share_file():
    """به اشتراک گذاری فایل بین کلاینت‌ها"""
    try:
        data = request.get_json()
        from_client = data.get('from_client')
        to_client = data.get('to_client')
        filename = data.get('filename')
        
        if not from_client or not to_client or not filename:
            return jsonify({'success': False, 'message': 'پارامترهای لازم ارسال نشده است'}), 400
        
        # بررسی دسترسی
        if not check_access(from_client, to_client):
            return jsonify({
                'success': False, 
                'message': f'کلاینت {from_client} اجازه دسترسی به {to_client} را ندارد'
            }), 403
        
        # بررسی وجود فایل
        from_folder = get_client_folder(from_client)
        filepath = os.path.join(from_folder, secure_filename(filename))
        
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'message': 'فایل پیدا نشد'}), 404
        
        # کپی فایل به پوشه مشترک یا ایجاد لینک نمادین
        # در اینجا فایل را کپی می‌کنیم تا هر کلاینت نسخه خود را داشته باشد
        to_folder = get_client_folder(to_client)
        os.makedirs(to_folder, exist_ok=True)
        
        shared_filepath = os.path.join(to_folder, f"shared_{from_client}_{filename}")
        shutil.copy2(filepath, shared_filepath)
        
        # ذخیره اطلاعات در دیتابیس
        shared_db = load_shared_files()
        share_id = f"{from_client}_{to_client}_{filename}_{datetime.now().isoformat()}"
        shared_db[share_id] = {
            'from_client': from_client,
            'to_client': to_client,
            'filename': filename,
            'shared_filename': f"shared_{from_client}_{filename}",
            'shared_at': datetime.now().isoformat()
        }
        save_shared_files(shared_db)
        
        return jsonify({
            'success': True,
            'message': f'فایل با موفقیت با {to_client} به اشتراک گذاشته شد'
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/shared-files', methods=['GET'])
def get_shared_files():
    """دریافت فایل‌های به اشتراک گذاشته شده"""
    try:
        from_client = request.args.get('from_client')
        to_client = request.args.get('to_client')
        
        if not from_client or not to_client:
            return jsonify({'success': False, 'message': 'پارامترهای لازم ارسال نشده است'}), 400
        
        shared_db = load_shared_files()
        shared_files = []
        
        for share_info in shared_db.values():
            if (share_info.get('from_client') == from_client and 
                share_info.get('to_client') == to_client):
                
                shared_filename = share_info.get('shared_filename')
                from_folder = get_client_folder(to_client)
                shared_filepath = os.path.join(from_folder, shared_filename)
                
                if os.path.exists(shared_filepath):
                    shared_files.append({
                        'name': share_info.get('filename'),
                        'shared_filename': shared_filename,
                        'size': os.path.getsize(shared_filepath),
                        'shared_at': share_info.get('shared_at')
                    })
        
        return jsonify({'success': True, 'files': shared_files}), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """بررسی سلامت API"""
    return jsonify({'success': True, 'status': 'healthy'}), 200

if __name__ == '__main__':
    # ایجاد پوشه‌های لازم
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    for client_id in ['domain1', 'domain2', 'subdomain']:
        os.makedirs(get_client_folder(client_id), exist_ok=True)
    
    init_shared_files_db()
    
    # اجرای سرور
    app.run(host='0.0.0.0', port=8000, debug=False)

