#!/bin/bash

# اسکریپت راه‌اندازی API

echo "راه‌اندازی API..."

# تعیین مسیر API
if [ -d "/var/www/api" ]; then
    API_DIR="/var/www/api"
else
    API_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fi

# فعال‌سازی محیط مجازی
if [ -d "$API_DIR/venv" ]; then
    echo "فعال‌سازی virtual environment..."
    source "$API_DIR/venv/bin/activate"
else
    echo "ایجاد virtual environment..."
    python3 -m venv "$API_DIR/venv"
    source "$API_DIR/venv/bin/activate"
    
    echo "نصب وابستگی‌ها..."
    pip install --upgrade pip -q
    if [ -f "$API_DIR/requirements.txt" ]; then
        pip install -r "$API_DIR/requirements.txt"
    else
        pip install Flask flask-cors Werkzeug
    fi
fi

# رفتن به دایرکتوری API
cd "$API_DIR"

# اجرای API
echo "اجرای API روی پورت 8000..."
python3 app.py

