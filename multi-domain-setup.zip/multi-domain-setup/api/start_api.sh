#!/bin/bash

# اسکریپت راه‌اندازی API

echo "راه‌اندازی API..."

# فعال‌سازی محیط مجازی (در صورت وجود)
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# نصب وابستگی‌ها
pip3 install -r requirements.txt

# اجرای API
python3 app.py

