#!/bin/bash

# ============================================
# اسکریپت حذف سیستم چند دامنه
# این اسکریپت تمام فایل‌ها و سرویس‌های نصب شده را حذف می‌کند
# ============================================

set -e

# رنگ‌ها
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo ""
    echo -e "${GREEN}==========================================${NC}"
    echo -e "${GREEN}$1${NC}"
    echo -e "${GREEN}==========================================${NC}"
    echo ""
}

# بررسی دسترسی root
if [ "$EUID" -ne 0 ]; then 
    print_error "لطفاً این اسکریپت را با sudo اجرا کنید"
    exit 1
fi

print_header "حذف سیستم چند دامنه"

# تایید حذف
read -p "آیا مطمئن هستید که می‌خواهید تمام فایل‌ها و سرویس‌ها را حذف کنید؟ (yes/no): " confirm
if [ "$confirm" != "yes" ]; then
    print_info "عملیات حذف لغو شد"
    exit 0
fi

# توقف سرویس‌ها
print_info "توقف سرویس API..."
systemctl stop multi-domain-api.service 2>/dev/null || true
systemctl disable multi-domain-api.service 2>/dev/null || true

# حذف سرویس systemd
print_info "حذف سرویس systemd..."
rm -f /etc/systemd/system/multi-domain-api.service
systemctl daemon-reload

# حذف پیکربندی Nginx
print_info "حذف پیکربندی Nginx..."
rm -f /etc/nginx/sites-enabled/domain1.com
rm -f /etc/nginx/sites-enabled/domain2.com
rm -f /etc/nginx/sites-enabled/subdomain.domain1.com
rm -f /etc/nginx/sites-available/domain1.com
rm -f /etc/nginx/sites-available/domain2.com
rm -f /etc/nginx/sites-available/subdomain.domain1.com

# راه‌اندازی مجدد Nginx
print_info "راه‌اندازی مجدد Nginx..."
systemctl restart nginx 2>/dev/null || true

# حذف فایل‌های پروژه
print_info "حذف فایل‌های پروژه..."
read -p "آیا می‌خواهید فایل‌های در /var/www را نیز حذف کنید؟ (yes/no): " delete_files
if [ "$delete_files" == "yes" ]; then
    rm -rf /var/www/domain1.com
    rm -rf /var/www/domain2.com
    rm -rf /var/www/subdomain.domain1.com
    rm -rf /var/www/shared_files
    rm -rf /var/www/api
    print_success "فایل‌های پروژه حذف شدند"
else
    print_info "فایل‌های پروژه حفظ شدند"
fi

# حذف از hosts (اختیاری)
read -p "آیا می‌خواهید دامنه‌ها را از /etc/hosts حذف کنید؟ (yes/no): " delete_hosts
if [ "$delete_hosts" == "yes" ]; then
    print_info "حذف دامنه‌ها از /etc/hosts..."
    sed -i '/# Multi-Domain Setup/,/subdomain.domain1.com/d' /etc/hosts 2>/dev/null || true
    print_success "دامنه‌ها از /etc/hosts حذف شدند"
fi

print_header "حذف با موفقیت انجام شد"

