#!/bin/bash

# ============================================
# اسکریپت نصب کامل و خودکار سیستم چند دامنه
# این اسکریپت تمام مراحل نصب و راه‌اندازی را انجام می‌دهد
# ============================================

set -e

# رنگ‌ها برای خروجی
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# متغیرهای پروژه
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WWW_DIR="/var/www"
API_DIR="$WWW_DIR/api"
SHARED_FILES_DIR="$WWW_DIR/shared_files"

# تابع برای نمایش پیام
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo ""
    echo -e "${GREEN}==========================================${NC}"
    echo -e "${GREEN}$1${NC}"
    echo -e "${GREEN}==========================================${NC}"
    echo ""
}

# بررسی دسترسی root
check_root() {
    if [ "$EUID" -ne 0 ]; then 
        print_error "لطفاً این اسکریپت را با sudo اجرا کنید"
        exit 1
    fi
}

# بررسی وجود دایرکتوری پروژه
check_project_dir() {
    if [ ! -d "$PROJECT_DIR" ]; then
        print_error "دایرکتوری پروژه پیدا نشد: $PROJECT_DIR"
        exit 1
    fi
    
    if [ ! -d "$PROJECT_DIR/clients" ] || [ ! -d "$PROJECT_DIR/api" ] || [ ! -d "$PROJECT_DIR/nginx" ]; then
        print_error "ساختار پروژه ناقص است. لطفاً مطمئن شوید که تمام فایل‌ها موجود هستند."
        exit 1
    fi
}

# به‌روزرسانی سیستم
update_system() {
    print_header "به‌روزرسانی سیستم"
    print_info "در حال به‌روزرسانی لیست پکیج‌ها..."
    apt-get update -qq
    print_success "سیستم به‌روزرسانی شد"
}

# نصب وابستگی‌ها
install_dependencies() {
    print_header "نصب وابستگی‌ها"
    
    print_info "بررسی پکیج‌های موجود..."
    
    # بررسی و نصب Nginx
    if ! command -v nginx &> /dev/null; then
        print_info "در حال نصب Nginx..."
        apt-get install -y nginx
        print_success "Nginx نصب شد"
    else
        print_success "Nginx از قبل نصب است"
    fi
    
    # بررسی و نصب Python3
    if ! command -v python3 &> /dev/null; then
        print_info "در حال نصب Python3..."
        apt-get install -y python3
        print_success "Python3 نصب شد"
    else
        print_success "Python3 از قبل نصب است"
    fi
    
    # بررسی و نصب pip3
    if ! command -v pip3 &> /dev/null; then
        print_info "در حال نصب pip3..."
        apt-get install -y python3-pip
        print_success "pip3 نصب شد"
    else
        print_success "pip3 از قبل نصب است"
    fi
    
    # نصب python3-venv (اختیاری اما مفید)
    if ! dpkg -l | grep -q python3-venv; then
        print_info "در حال نصب python3-venv..."
        apt-get install -y python3-venv
        print_success "python3-venv نصب شد"
    fi
}

# نصب پکیج‌های Python
install_python_packages() {
    print_header "نصب پکیج‌های Python"
    
    if [ -f "$PROJECT_DIR/api/requirements.txt" ]; then
        print_info "نصب پکیج‌ها از requirements.txt..."
        pip3 install -q -r "$PROJECT_DIR/api/requirements.txt"
        print_success "پکیج‌های Python نصب شدند"
    else
        print_warning "فایل requirements.txt پیدا نشد، نصب دستی پکیج‌ها..."
        pip3 install -q Flask flask-cors Werkzeug
        print_success "پکیج‌های Python نصب شدند"
    fi
}

# ایجاد ساختار دایرکتوری
create_directories() {
    print_header "ایجاد ساختار دایرکتوری"
    
    print_info "ایجاد دایرکتوری‌های اصلی..."
    mkdir -p "$WWW_DIR/domain1.com"
    mkdir -p "$WWW_DIR/domain2.com"
    mkdir -p "$WWW_DIR/subdomain.domain1.com"
    mkdir -p "$SHARED_FILES_DIR"
    mkdir -p "$SHARED_FILES_DIR/domain1"
    mkdir -p "$SHARED_FILES_DIR/domain2"
    mkdir -p "$SHARED_FILES_DIR/subdomain"
    mkdir -p "$API_DIR"
    
    print_success "ساختار دایرکتوری ایجاد شد"
}

# تنظیم مجوزها
set_permissions() {
    print_header "تنظیم مجوزها"
    
    print_info "تنظیم مالکیت فایل‌ها..."
    chown -R www-data:www-data "$WWW_DIR/domain1.com"
    chown -R www-data:www-data "$WWW_DIR/domain2.com"
    chown -R www-data:www-data "$WWW_DIR/subdomain.domain1.com"
    chown -R www-data:www-data "$SHARED_FILES_DIR"
    chown -R www-data:www-data "$API_DIR"
    
    print_info "تنظیم مجوزهای دسترسی..."
    chmod -R 755 "$WWW_DIR/domain1.com"
    chmod -R 755 "$WWW_DIR/domain2.com"
    chmod -R 755 "$WWW_DIR/subdomain.domain1.com"
    chmod -R 755 "$SHARED_FILES_DIR"
    chmod -R 755 "$API_DIR"
    
    # مجوزهای نوشتن برای پوشه‌های shared_files
    chmod -R 777 "$SHARED_FILES_DIR/domain1"
    chmod -R 777 "$SHARED_FILES_DIR/domain2"
    chmod -R 777 "$SHARED_FILES_DIR/subdomain"
    
    print_success "مجوزها تنظیم شدند"
}

# کپی فایل‌های کلاینت
copy_client_files() {
    print_header "کپی فایل‌های کلاینت"
    
    print_info "کپی فایل‌های domain1.com..."
    if [ -d "$PROJECT_DIR/clients/domain1" ]; then
        cp -r "$PROJECT_DIR/clients/domain1"/* "$WWW_DIR/domain1.com/"
        print_success "فایل‌های domain1.com کپی شدند"
    else
        print_error "دایرکتوری clients/domain1 پیدا نشد"
        exit 1
    fi
    
    print_info "کپی فایل‌های domain2.com..."
    if [ -d "$PROJECT_DIR/clients/domain2" ]; then
        cp -r "$PROJECT_DIR/clients/domain2"/* "$WWW_DIR/domain2.com/"
        print_success "فایل‌های domain2.com کپی شدند"
    else
        print_error "دایرکتوری clients/domain2 پیدا نشد"
        exit 1
    fi
    
    print_info "کپی فایل‌های subdomain.domain1.com..."
    if [ -d "$PROJECT_DIR/clients/subdomain" ]; then
        cp -r "$PROJECT_DIR/clients/subdomain"/* "$WWW_DIR/subdomain.domain1.com/"
        print_success "فایل‌های subdomain.domain1.com کپی شدند"
    else
        print_error "دایرکتوری clients/subdomain پیدا نشد"
        exit 1
    fi
}

# کپی فایل‌های API
copy_api_files() {
    print_header "کپی فایل‌های API"
    
    print_info "کپی فایل‌های API..."
    if [ -d "$PROJECT_DIR/api" ]; then
        cp -r "$PROJECT_DIR/api"/* "$API_DIR/"
        print_success "فایل‌های API کپی شدند"
    else
        print_error "دایرکتوری api پیدا نشد"
        exit 1
    fi
}

# پیکربندی Nginx
configure_nginx() {
    print_header "پیکربندی Nginx"
    
    print_info "کپی فایل‌های پیکربندی Nginx..."
    
    if [ -f "$PROJECT_DIR/nginx/domain1.com" ]; then
        cp "$PROJECT_DIR/nginx/domain1.com" /etc/nginx/sites-available/
        print_success "پیکربندی domain1.com کپی شد"
    else
        print_error "فایل nginx/domain1.com پیدا نشد"
        exit 1
    fi
    
    if [ -f "$PROJECT_DIR/nginx/domain2.com" ]; then
        cp "$PROJECT_DIR/nginx/domain2.com" /etc/nginx/sites-available/
        print_success "پیکربندی domain2.com کپی شد"
    else
        print_error "فایل nginx/domain2.com پیدا نشد"
        exit 1
    fi
    
    if [ -f "$PROJECT_DIR/nginx/subdomain.domain1.com" ]; then
        cp "$PROJECT_DIR/nginx/subdomain.domain1.com" /etc/nginx/sites-available/
        print_success "پیکربندی subdomain.domain1.com کپی شد"
    else
        print_error "فایل nginx/subdomain.domain1.com پیدا نشد"
        exit 1
    fi
    
    print_info "فعال‌سازی سایت‌های Nginx..."
    ln -sf /etc/nginx/sites-available/domain1.com /etc/nginx/sites-enabled/
    ln -sf /etc/nginx/sites-available/domain2.com /etc/nginx/sites-enabled/
    ln -sf /etc/nginx/sites-available/subdomain.domain1.com /etc/nginx/sites-enabled/
    
    print_success "سایت‌های Nginx فعال شدند"
    
    # حذف سایت پیش‌فرض Nginx (در صورت وجود)
    if [ -f /etc/nginx/sites-enabled/default ]; then
        print_info "حذف سایت پیش‌فرض Nginx..."
        rm -f /etc/nginx/sites-enabled/default
        print_success "سایت پیش‌فرض حذف شد"
    fi
    
    # تست پیکربندی Nginx
    print_info "تست پیکربندی Nginx..."
    if nginx -t; then
        print_success "پیکربندی Nginx معتبر است"
    else
        print_error "خطا در پیکربندی Nginx"
        exit 1
    fi
}

# راه‌اندازی سرویس API
setup_api_service() {
    print_header "راه‌اندازی سرویس API"
    
    if [ -f "$PROJECT_DIR/api/systemd/api.service" ]; then
        print_info "کپی فایل سرویس systemd..."
        cp "$PROJECT_DIR/api/systemd/api.service" /etc/systemd/system/multi-domain-api.service
        
        print_info "بارگذاری مجدد systemd..."
        systemctl daemon-reload
        
        print_info "فعال‌سازی سرویس API..."
        systemctl enable multi-domain-api.service
        
        print_info "شروع سرویس API..."
        systemctl start multi-domain-api.service
        
        # صبر برای راه‌اندازی سرویس
        sleep 3
        
        # بررسی وضعیت سرویس
        if systemctl is-active --quiet multi-domain-api.service; then
            print_success "سرویس API با موفقیت راه‌اندازی شد"
        else
            print_warning "سرویس API راه‌اندازی نشد. بررسی لاگ‌ها..."
            systemctl status multi-domain-api.service --no-pager || true
        fi
    else
        print_error "فایل api/systemd/api.service پیدا نشد"
        exit 1
    fi
}

# راه‌اندازی مجدد Nginx
restart_nginx() {
    print_header "راه‌اندازی مجدد Nginx"
    
    print_info "راه‌اندازی مجدد Nginx..."
    systemctl restart nginx
    
    sleep 2
    
    if systemctl is-active --quiet nginx; then
        print_success "Nginx با موفقیت راه‌اندازی شد"
    else
        print_error "Nginx راه‌اندازی نشد. بررسی لاگ‌ها..."
        systemctl status nginx --no-pager || true
        exit 1
    fi
}

# تنظیم فایل hosts برای تست محلی (اختیاری)
setup_hosts_file() {
    print_header "تنظیم فایل hosts (برای تست محلی)"
    
    read -p "آیا می‌خواهید دامنه‌ها را به فایل /etc/hosts اضافه کنید؟ (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_info "افزودن دامنه‌ها به /etc/hosts..."
        
        # بررسی وجود قبلی
        if grep -q "domain1.com" /etc/hosts; then
            print_warning "دامنه‌ها از قبل در /etc/hosts وجود دارند"
        else
            echo "" >> /etc/hosts
            echo "# Multi-Domain Setup" >> /etc/hosts
            echo "127.0.0.1    domain1.com" >> /etc/hosts
            echo "127.0.0.1    www.domain1.com" >> /etc/hosts
            echo "127.0.0.1    domain2.com" >> /etc/hosts
            echo "127.0.0.1    www.domain2.com" >> /etc/hosts
            echo "127.0.0.1    subdomain.domain1.com" >> /etc/hosts
            print_success "دامنه‌ها به /etc/hosts اضافه شدند"
        fi
    else
        print_info "تنظیم فایل hosts رد شد"
    fi
}

# نمایش وضعیت سرویس‌ها
show_status() {
    print_header "وضعیت سرویس‌ها"
    
    echo -e "${BLUE}وضعیت Nginx:${NC}"
    systemctl status nginx --no-pager -l || true
    
    echo ""
    echo -e "${BLUE}وضعیت API:${NC}"
    systemctl status multi-domain-api.service --no-pager -l || true
}

# نمایش اطلاعات نهایی
show_final_info() {
    print_header "نصب با موفقیت انجام شد!"
    
    echo -e "${GREEN}✓${NC} تمام مراحل نصب با موفقیت انجام شد"
    echo ""
    echo -e "${YELLOW}مراحل بعدی:${NC}"
    echo ""
    echo "1. ${BLUE}تنظیم DNS${NC} (در صورت استفاده از دامنه واقعی):"
    echo "   - domain1.com → IP سرور"
    echo "   - domain2.com → IP سرور"
    echo "   - subdomain.domain1.com → IP سرور"
    echo ""
    echo "2. ${BLUE}دسترسی به کلاینت‌ها:${NC}"
    echo "   - http://domain1.com"
    echo "   - http://domain2.com"
    echo "   - http://subdomain.domain1.com"
    echo ""
    echo "3. ${BLUE}بررسی وضعیت سرویس‌ها:${NC}"
    echo "   sudo systemctl status nginx"
    echo "   sudo systemctl status multi-domain-api.service"
    echo ""
    echo "4. ${BLUE}مشاهده لاگ‌ها:${NC}"
    echo "   sudo tail -f /var/log/nginx/error.log"
    echo "   sudo journalctl -u multi-domain-api.service -f"
    echo ""
    echo -e "${GREEN}سیستم آماده استفاده است!${NC}"
    echo ""
}

# تابع اصلی
main() {
    print_header "شروع نصب سیستم چند دامنه"
    
    # بررسی‌های اولیه
    check_root
    check_project_dir
    
    # مراحل نصب
    update_system
    install_dependencies
    install_python_packages
    create_directories
    copy_client_files
    copy_api_files
    set_permissions
    configure_nginx
    setup_api_service
    restart_nginx
    
    # تنظیمات اختیاری
    setup_hosts_file
    
    # نمایش وضعیت
    show_status
    
    # نمایش اطلاعات نهایی
    show_final_info
}

# اجرای تابع اصلی
main

