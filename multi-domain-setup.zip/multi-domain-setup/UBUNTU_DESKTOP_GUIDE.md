# راهنمای نصب روی Ubuntu Desktop

## ✅ آیا این پروژه روی Ubuntu Desktop کار می‌کند؟

**بله!** این پروژه به طور کامل روی Ubuntu Desktop قابل اجرا است. تمام کامپوننت‌های مورد نیاز (Nginx، Python، systemd) در Ubuntu Desktop نیز موجود هستند.

## تفاوت‌های Ubuntu Desktop و Server

تفاوت اصلی فقط در وجود رابط گرافیکی است. تمام ابزارهای سرور به همان شکل کار می‌کنند.

## مراحل نصب روی Ubuntu Desktop

### 1. نصب وابستگی‌ها

```bash
# به‌روزرسانی سیستم
sudo apt update

# نصب وابستگی‌ها (در صورت عدم نصب)
sudo apt install -y nginx python3 python3-pip python3-venv
```

### 2. اجرای اسکریپت نصب

```bash
cd multi-domain-setup
sudo bash install.sh
```

### 3. تنظیمات برای استفاده محلی (بدون دامنه واقعی)

اگر می‌خواهید روی سیستم محلی خود تست کنید، می‌توانید از فایل `/etc/hosts` استفاده کنید:

```bash
# ویرایش فایل hosts
sudo nano /etc/hosts

# اضافه کردن خطوط زیر:
127.0.0.1    domain1.com
127.0.0.1    domain2.com
127.0.0.1    subdomain.domain1.com
```

سپس می‌توانید از طریق مرورگر به آدرس‌های زیر دسترسی داشته باشید:
- `http://domain1.com`
- `http://domain2.com`
- `http://subdomain.domain1.com`

### 4. راه‌اندازی مجدد Nginx

```bash
sudo systemctl restart nginx
```

### 5. بررسی وضعیت سرویس‌ها

```bash
# بررسی Nginx
sudo systemctl status nginx

# بررسی API
sudo systemctl status multi-domain-api.service
```

## استفاده از رابط گرافیکی

در Ubuntu Desktop می‌توانید:

1. **از Terminal استفاده کنید**: تمام دستورات مشابه Ubuntu Server است
2. **از مرورگر استفاده کنید**: می‌توانید از مرورگر پیش‌فرض برای دسترسی به کلاینت‌ها استفاده کنید
3. **از File Manager استفاده کنید**: می‌توانید فایل‌های در `/var/www/` را مشاهده کنید

## نکات مهم برای Ubuntu Desktop

### 1. فایروال

اگر فایروال فعال است، پورت‌های 80 و 443 را باز کنید:

```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

### 2. دسترسی به فایل‌ها

برای دسترسی به فایل‌های پروژه در File Manager:

```bash
# تغییر مالکیت برای دسترسی راحت‌تر (اختیاری)
sudo chown -R $USER:$USER /var/www/
```

⚠️ **توجه**: این کار فقط برای دسترسی راحت‌تر است. برای تولید، بهتر است مجوزها را به `www-data` بدهید.

### 3. اجرای دستی API (برای تست)

اگر می‌خواهید API را به صورت دستی اجرا کنید:

```bash
cd /var/www/api
python3 app.py
```

### 4. مشاهده لاگ‌ها

```bash
# لاگ‌های Nginx
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log

# لاگ‌های API
sudo journalctl -u multi-domain-api.service -f
```

## تست محلی بدون دامنه

برای تست سریع بدون تنظیم DNS یا hosts:

1. **استفاده از localhost با پورت‌های مختلف**:
   - می‌توانید پیکربندی Nginx را تغییر دهید تا از پورت‌های مختلف استفاده کند
   - یا مستقیماً از IP محلی استفاده کنید: `http://127.0.0.1`

2. **تغییر پیکربندی Nginx برای localhost**:
   ```bash
   sudo nano /etc/nginx/sites-available/domain1.com
   ```
   و تغییر `server_name` به `localhost` یا `127.0.0.1`

## عیب‌یابی

### مشکل: Nginx شروع نمی‌شود

```bash
# بررسی خطاهای پیکربندی
sudo nginx -t

# بررسی لاگ‌ها
sudo tail -f /var/log/nginx/error.log
```

### مشکل: API کار نمی‌کند

```bash
# بررسی وضعیت سرویس
sudo systemctl status multi-domain-api.service

# بررسی لاگ‌ها
sudo journalctl -u multi-domain-api.service -n 50

# راه‌اندازی مجدد
sudo systemctl restart multi-domain-api.service
```

### مشکل: دسترسی به فایل‌ها

```bash
# تنظیم مجدد مجوزها
sudo chown -R www-data:www-data /var/www/
sudo chmod -R 755 /var/www/
```

## مزایای استفاده از Ubuntu Desktop

1. ✅ رابط گرافیکی برای مدیریت راحت‌تر
2. ✅ دسترسی آسان به فایل‌ها از طریق File Manager
3. ✅ استفاده از مرورگر برای تست سریع
4. ✅ ابزارهای توسعه بیشتر در دسترس

## نتیجه‌گیری

این پروژه به طور کامل روی Ubuntu Desktop قابل اجرا است و تفاوتی با Ubuntu Server ندارد. تمام دستورات و مراحل نصب یکسان است.



















chmod +x install-complete.sh uninstall.sh restart.sh status.sh update.sh