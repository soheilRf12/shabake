راهنمای مرحله به مرحله اجرای فایل‌ها

این راهنما تمام مراحل اجرای پروژه را به صورت کامل و مرحله به مرحله توضیح می‌دهد.

---

## 📋 فهرست مطالب

1. [پیش‌نیازها](#پیش‌نیازها)
2. [مرحله 1: آماده‌سازی اولیه](#مرحله-1-آماده‌سازی-اولیه)
3. [مرحله 2: نصب سیستم](#مرحله-2-نصب-سیستم)
4. [مرحله 3: بررسی وضعیت](#مرحله-3-بررسی-وضعیت)
5. [مرحله 4: تنظیم DNS یا hosts](#مرحله-4-تنظیم-dns-یا-hosts)
6. [مرحله 5: تست و استفاده](#مرحله-5-تست-و-استفاده)
7. [دستورات مدیریتی](#دستورات-مدیریتی)
8. [عیب‌یابی](#عیب‌یابی)

---

## پیش‌نیازها

قبل از شروع، مطمئن شوید:

- ✅ سیستم عامل: Ubuntu 18.04 یا بالاتر (Server یا Desktop)
- ✅ دسترسی root یا sudo
- ✅ اتصال به اینترنت
- ✅ حداقل 2GB RAM و 10GB فضای دیسک

---

## مرحله 1: آماده‌سازی اولیه

### گام 1.1: آپلود فایل‌های پروژه به سرور

**روش 1: استفاده از SCP (از سیستم محلی)**
```bash
scp -r multi-domain-setup user@your-server-ip:/home/user/
```

**روش 2: استفاده از Git (روی سرور)**
```bash
git clone <repository-url>
cd multi-domain-setup
```

**روش 3: آپلود دستی**
- فایل‌های پروژه را با FTP/SFTP به سرور آپلود کنید

### گام 1.2: اتصال به سرور

```bash
ssh user@your-server-ip
```

### گام 1.3: رفتن به دایرکتوری پروژه

```bash
cd multi-domain-setup
```

### گام 1.4: بررسی ساختار فایل‌ها

```bash
ls -la
```

باید فایل‌های زیر را ببینید:
- `install.sh`
- `install-complete.sh`
- `setup.sh`
- `restart.sh`
- `status.sh`
- `update.sh`
- `uninstall.sh`
- پوشه `api/`
- پوشه `clients/`
- پوشه `nginx/`

### گام 1.5: دادن مجوز اجرا به فایل‌های Bash (اختیاری اما توصیه می‌شود)

```bash
chmod +x *.sh
chmod +x api/*.sh
```

---

## مرحله 2: نصب سیستم

### روش A: نصب سریع (توصیه می‌شود برای شروع)

```bash
sudo bash install.sh
```

**این اسکریپت به صورت خودکار:**
1. سیستم را به‌روزرسانی می‌کند (`apt update`)
2. Nginx، Python3 و pip3 را نصب می‌کند
3. پکیج‌های Python را نصب می‌کند (Flask، flask-cors، Werkzeug)
4. ساختار دایرکتوری را ایجاد می‌کند
5. فایل‌های کلاینت را کپی می‌کند
6. فایل‌های API را کپی می‌کند
7. پیکربندی Nginx را تنظیم می‌کند
8. سرویس API را راه‌اندازی می‌کند

**زمان تقریبی:** 2-5 دقیقه

**نکته مهم:** این اسکریپت به صورت خودکار از virtual environment استفاده می‌کند و مشکل `externally-managed-environment` را حل می‌کند.

### روش B: نصب کامل (با بررسی‌های بیشتر)

```bash
sudo bash install-complete.sh
```

**مزایای این روش:**
- ✅ بررسی‌های دقیق‌تر قبل از نصب
- ✅ بررسی وجود پکیج‌ها
- ✅ گزینه تنظیم خودکار فایل `/etc/hosts` برای تست محلی
- ✅ نمایش وضعیت نهایی سرویس‌ها

**زمان تقریبی:** 3-7 دقیقه

**نکته:** اگر از `install-complete.sh` استفاده می‌کنید، در حین اجرا از شما سوال می‌شود که آیا می‌خواهید دامنه‌ها را به `/etc/hosts` اضافه کنید. برای تست محلی `y` را وارد کنید.

**نکته مهم:** این اسکریپت به صورت خودکار از virtual environment استفاده می‌کند و مشکل `externally-managed-environment` در Ubuntu 23.04+ را حل می‌کند.

---

## مرحله 3: بررسی وضعیت

پس از نصب، حتماً وضعیت سیستم را بررسی کنید:

```bash
bash status.sh
```

**یا برای اطلاعات کامل‌تر:**

```bash
sudo bash status.sh
```

**این اسکریپت نمایش می‌دهد:**
- ✅ وضعیت Nginx (در حال اجرا یا خاموش)
- ✅ وضعیت سرویس API
- ✅ وجود دایرکتوری‌های پروژه
- ✅ اعتبار پیکربندی Nginx
- ✅ پورت‌های در حال استفاده
- ✅ آدرس‌های دسترسی

**بررسی دستی سرویس‌ها:**

```bash
# بررسی Nginx
sudo systemctl status nginx

# بررسی API
sudo systemctl status multi-domain-api.service
```

**اگر سرویس‌ها در حال اجرا نیستند:**

```bash
# راه‌اندازی Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# راه‌اندازی API
sudo systemctl start multi-domain-api.service
sudo systemctl enable multi-domain-api.service
```

---

## مرحله 4: تنظیم DNS یا hosts

### گزینه A: استفاده از DNS واقعی (برای تولید)

در پنل مدیریت DNS خود (مثل Cloudflare، Namecheap و غیره)، رکوردهای زیر را اضافه کنید:

```
A Record: domain1.com → IP سرور شما
A Record: www.domain1.com → IP سرور شما
A Record: domain2.com → IP سرور شما
A Record: www.domain2.com → IP سرور شما
A Record: subdomain.domain1.com → IP سرور شما
```

**انتظار برای انتشار DNS:** 5 دقیقه تا 24 ساعت (معمولاً 5-30 دقیقه)

**بررسی DNS:**

```bash
# بررسی DNS
nslookup domain1.com
nslookup domain2.com
nslookup subdomain.domain1.com
```

### گزینه B: استفاده از /etc/hosts (برای تست محلی)

اگر می‌خواهید روی سیستم محلی خود تست کنید:

```bash
sudo nano /etc/hosts
```

**اضافه کردن خطوط زیر:**

```
127.0.0.1    domain1.com
127.0.0.1    www.domain1.com
127.0.0.1    domain2.com
127.0.0.1    www.domain2.com
127.0.0.1    subdomain.domain1.com
```

**ذخیره:** `Ctrl+O` سپس `Enter`، سپس `Ctrl+X` برای خروج

**نکته:** اگر از `install-complete.sh` استفاده کردید و گزینه تنظیم hosts را انتخاب کردید، این کار به صورت خودکار انجام شده است.

---

## مرحله 5: تست و استفاده

### گام 5.1: راه‌اندازی مجدد Nginx

```bash
sudo systemctl restart nginx
```

### گام 5.2: بررسی لاگ‌های Nginx

```bash
# بررسی خطاها
sudo tail -f /var/log/nginx/error.log

# بررسی دسترسی‌ها
sudo tail -f /var/log/nginx/access.log
```

### گام 5.3: دسترسی به کلاینت‌ها

در مرورگر خود به آدرس‌های زیر بروید:

- ✅ `http://domain1.com` - کلاینت دامنه اصلی 1
- ✅ `http://domain2.com` - کلاینت دامنه اصلی 2
- ✅ `http://subdomain.domain1.com` - کلاینت زیردامنه

**اگر از hosts استفاده می‌کنید:** از همان آدرس‌ها استفاده کنید

**اگر DNS تنظیم شده:** منتظر انتشار DNS بمانید

### گام 5.4: تست عملکرد

**در هر کلاینت می‌توانید:**
1. ✅ فایل آپلود کنید
2. ✅ فایل‌ها را مشاهده کنید
3. ✅ فایل‌ها را دانلود کنید
4. ✅ فایل‌ها را حذف کنید

**تست به اشتراک‌گذاری فایل:**

1. به `http://subdomain.domain1.com` بروید
2. یک فایل آپلود کنید
3. روی دکمه "اشتراک با Domain2" کلیک کنید
4. به `http://domain2.com` بروید
5. در بخش "فایل‌های به اشتراک گذاشته شده از زیردامنه" فایل را مشاهده کنید
6. فایل را دانلود کنید

---

## دستورات مدیریتی

### راه‌اندازی مجدد سرویس‌ها

```bash
sudo bash restart.sh
```

**یا به صورت دستی:**

```bash
sudo systemctl restart multi-domain-api.service
sudo systemctl restart nginx
```

### به‌روزرسانی فایل‌ها

پس از تغییر فایل‌های پروژه:

```bash
sudo bash update.sh
```

**این اسکریپت:**
- پکیج‌های Python را به‌روزرسانی می‌کند
- فایل‌های کلاینت را کپی می‌کند
- فایل‌های API را کپی می‌کند
- مجوزها را تنظیم می‌کند
- سرویس‌ها را راه‌اندازی مجدد می‌کند

### بررسی وضعیت

```bash
bash status.sh
```

### اجرای دستی API (برای تست)

```bash
# توقف سرویس systemd
sudo systemctl stop multi-domain-api.service

# اجرای دستی
cd api
bash start_api.sh

# برای توقف: Ctrl+C
```

### مشاهده لاگ‌ها

```bash
# لاگ‌های Nginx
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log

# لاگ‌های API
sudo journalctl -u multi-domain-api.service -f

# لاگ‌های اخیر API
sudo journalctl -u multi-domain-api.service -n 50
```

---

## عیب‌یابی

### مشکل 1: Nginx شروع نمی‌شود

**بررسی پیکربندی:**

```bash
sudo nginx -t
```

**بررسی لاگ‌ها:**

```bash
sudo tail -f /var/log/nginx/error.log
```

**راه‌حل:**
- اگر خطای پیکربندی وجود دارد، فایل‌های پیکربندی را بررسی کنید
- مطمئن شوید پورت 80 و 443 باز هستند

### مشکل 2: API کار نمی‌کند

**بررسی وضعیت:**

```bash
sudo systemctl status multi-domain-api.service
```

**بررسی لاگ‌ها:**

```bash
sudo journalctl -u multi-domain-api.service -n 50
```

**راه‌اندازی مجدد:**

```bash
sudo systemctl restart multi-domain-api.service
```

**بررسی پورت:**

```bash
sudo netstat -tlnp | grep 8000
```

### مشکل 3: کلاینت‌ها بارگذاری نمی‌شوند

**بررسی:**

```bash
# بررسی Nginx
sudo systemctl status nginx

# بررسی پیکربندی
sudo nginx -t

# بررسی لاگ‌ها
sudo tail -f /var/log/nginx/error.log
```

**راه‌حل:**
- مطمئن شوید Nginx در حال اجرا است
- پیکربندی Nginx را بررسی کنید
- مجوزهای فایل‌ها را بررسی کنید

### مشکل 4: فایل‌ها آپلود نمی‌شوند

**بررسی مجوزها:**

```bash
sudo chown -R www-data:www-data /var/www/shared_files
sudo chmod -R 755 /var/www/shared_files
```

**بررسی فضای دیسک:**

```bash
df -h
```

**بررسی محدودیت اندازه فایل در Nginx:**

```bash
sudo nano /etc/nginx/nginx.conf
```

مطمئن شوید این خط وجود دارد:
```nginx
client_max_body_size 100M;
```

سپس:
```bash
sudo systemctl restart nginx
```

### مشکل 5: دسترسی به دامنه‌ها کار نمی‌کند

**بررسی DNS:**

```bash
nslookup domain1.com
nslookup domain2.com
nslookup subdomain.domain1.com
```

**اگر از hosts استفاده می‌کنید:**

```bash
cat /etc/hosts
```

مطمئن شوید دامنه‌ها اضافه شده‌اند.

### مشکل 6: "Permission denied" هنگام اجرای اسکریپت

**راه‌حل:**

```bash
chmod +x نام_فایل.sh
sudo bash نام_فایل.sh
```

### مشکل 7: خطای "externally-managed-environment" در نصب پکیج‌های Python

**مشکل:** در Ubuntu 23.04 و بالاتر، pip نمی‌تواند به صورت مستقیم پکیج‌ها را در سیستم نصب کند.

**خطا:**
```
error: externally-managed-environment
```

**راه‌حل:** اسکریپت‌های نصب به‌روزرسانی شده‌اند و به صورت خودکار از virtual environment استفاده می‌کنند. اگر هنوز این خطا را می‌بینید:

**روش 1: استفاده از اسکریپت‌های به‌روزرسانی شده (توصیه می‌شود)**
```bash
# اسکریپت‌ها به‌روزرسانی شده‌اند و از virtual environment استفاده می‌کنند
sudo bash install-complete.sh
```

**روش 2: نصب دستی با virtual environment**
```bash
# ایجاد virtual environment
sudo python3 -m venv /var/www/api/venv

# فعال‌سازی
sudo source /var/www/api/venv/bin/activate

# نصب پکیج‌ها
sudo /var/www/api/venv/bin/pip install -r api/requirements.txt

# غیرفعال‌سازی
deactivate
```

**روش 3: استفاده از --break-system-packages (توصیه نمی‌شود)**
```bash
# فقط در صورت ضرورت
pip3 install --break-system-packages Flask flask-cors Werkzeug
```

**نکته:** اسکریپت‌های `install.sh` و `install-complete.sh` به‌روزرسانی شده‌اند و به صورت خودکار virtual environment ایجاد می‌کنند و از آن استفاده می‌کنند.

---

## خلاصه مراحل سریع

برای کسانی که می‌خواهند سریع شروع کنند:

```bash
# 1. رفتن به دایرکتوری پروژه
cd multi-domain-setup

# 2. نصب
sudo bash install-complete.sh

# 3. بررسی وضعیت
bash status.sh

# 4. راه‌اندازی مجدد Nginx
sudo systemctl restart nginx

# 5. تست در مرورگر
# http://domain1.com
# http://domain2.com
# http://subdomain.domain1.com
```

---

## حذف سیستم (در صورت نیاز)

⚠️ **هشدار:** این کار تمام فایل‌ها و سرویس‌ها را حذف می‌کند!

```bash
sudo bash uninstall.sh
```

این اسکریپت:
- سرویس API را متوقف و حذف می‌کند
- پیکربندی Nginx را حذف می‌کند
- فایل‌های پروژه را حذف می‌کند (با تایید)
- دامنه‌ها را از hosts حذف می‌کند (با تایید)

---

## نکات مهم

1. ✅ **همیشه از sudo استفاده کنید** برای فایل‌هایی که نیاز به دسترسی root دارند
2. ✅ **پس از نصب** حتماً `status.sh` را اجرا کنید
3. ✅ **برای تست محلی** از `install-complete.sh` استفاده کنید و گزینه hosts را انتخاب کنید
4. ✅ **برای به‌روزرسانی** از `update.sh` استفاده کنید، نه `install.sh`
5. ✅ **قبل از حذف** مطمئن شوید که می‌خواهید همه چیز را حذف کنید
6. ✅ **برای تولید** حتماً DNS را تنظیم کنید و HTTPS را فعال کنید

---

## مستندات بیشتر

- `INSTALLATION_GUIDE.md` - راهنمای کامل نصب
- `QUICK_START.md` - راهنمای سریع
- `BASH_SCRIPTS_GUIDE.md` - راهنمای کامل فایل‌های Bash
- `UBUNTU_DESKTOP_GUIDE.md` - راهنمای نصب روی Ubuntu Desktop
- `README.md` - خلاصه پروژه

---

## پشتیبانی

در صورت بروز مشکل:
1. ✅ لاگ‌های سیستم را بررسی کنید
2. ✅ وضعیت سرویس‌ها را چک کنید (`status.sh`)
3. ✅ پیکربندی‌ها را بررسی کنید
4. ✅ بخش عیب‌یابی این راهنما را مطالعه کنید

---

**موفق باشید! 🚀**

