# راهنمای راه‌اندازی سیستم چند دامنه با انتقال فایل

## ساختار دامنه‌ها

- **دامنه اصلی 1**: `domain1.com`
- **دامنه اصلی 2**: `domain2.com`
- **زیردامنه**: `subdomain.domain1.com`

هر دامنه یک کلاینت وب دارد که می‌تواند فایل‌ها را با کلاینت‌های دیگر به اشتراک بگذارد.

## ویژگی‌ها

- کلاینت زیردامنه می‌تواند به کلاینت دامنه 2 دسترسی داشته باشد
- انتقال فایل بین کلاینت‌ها
- رابط کاربری وب برای هر کلاینت
- API RESTful برای مدیریت فایل‌ها

## ساختار دایرکتوری

```
/var/www/
├── domain1.com/          # کلاینت دامنه اصلی 1
├── domain2.com/          # کلاینت دامنه اصلی 2
├── subdomain.domain1.com/ # کلاینت زیردامنه
└── shared_files/         # پوشه مشترک برای فایل‌ها
```

## نصب و راه‌اندازی

### روش سریع (توصیه می‌شود)

```bash
sudo bash install.sh
```

این اسکریپت به صورت خودکار تمام مراحل را انجام می‌دهد.

### روش دستی

1. اجرای اسکریپت راه‌اندازی:
```bash
sudo bash setup.sh
```

2. نصب وابستگی‌های Python:
```bash
cd api
pip3 install -r requirements.txt
```

3. راه‌اندازی API:
```bash
# کپی سرویس systemd
sudo cp api/systemd/api.service /etc/systemd/system/multi-domain-api.service
sudo systemctl daemon-reload
sudo systemctl enable multi-domain-api.service
sudo systemctl start multi-domain-api.service
```

4. تنظیم DNS:
- `domain1.com` → IP سرور
- `domain2.com` → IP سرور
- `subdomain.domain1.com` → IP سرور

5. راه‌اندازی مجدد Nginx:
```bash
sudo systemctl restart nginx
```

برای راهنمای کامل، فایل `INSTALLATION_GUIDE.md` را مطالعه کنید.

## دسترسی‌ها

- ✅ کلاینت زیردامنه (`subdomain.domain1.com`) می‌تواند فایل‌ها را با کلاینت دامنه 2 (`domain2.com`) به اشتراک بگذارد
- ✅ هر کلاینت می‌تواند فایل‌های خود را مدیریت کند (آپلود، دانلود، حذف)
- ❌ سایر کلاینت‌ها دسترسی به یکدیگر ندارند

## مستندات

- `INSTALLATION_GUIDE.md` - راهنمای کامل نصب و راه‌اندازی
- `QUICK_START.md` - راهنمای سریع شروع کار
- `SUMMARY_FA.md` - خلاصه پروژه و معماری سیستم
- `UBUNTU_DESKTOP_GUIDE.md` - راهنمای نصب روی Ubuntu Desktop
- `BASH_SCRIPTS_GUIDE.md` - راهنمای کامل اجرای فایل‌های Bash

## پشتیبانی از سیستم‌عامل

✅ **Ubuntu Server** (18.04 یا بالاتر) - پشتیبانی کامل  
✅ **Ubuntu Desktop** (18.04 یا بالاتر) - پشتیبانی کامل  
ℹ️ تمام دستورات و مراحل نصب برای هر دو نسخه یکسان است.

## ویژگی‌های کلاینت‌ها

هر کلاینت دارای:
- رابط کاربری زیبا و مدرن
- آپلود فایل (چند فایل همزمان)
- دانلود فایل
- حذف فایل
- مشاهده لیست فایل‌ها
- نمایش فایل‌های به اشتراک گذاشته شده (در کلاینت دامنه 2)

