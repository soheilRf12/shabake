#!/bin/bash

# اسکریپت راه‌اندازی سیستم چند دامنه
# این اسکریپت ساختار دایرکتوری و پیکربندی‌های لازم را ایجاد می‌کند

set -e

echo "=========================================="
echo "راه‌اندازی سیستم چند دامنه"
echo "=========================================="

# بررسی دسترسی root
if [ "$EUID" -ne 0 ]; then 
    echo "لطفاً این اسکریپت را با sudo اجرا کنید"
    exit 1
fi

# ایجاد ساختار دایرکتوری
echo "در حال ایجاد ساختار دایرکتوری..."
mkdir -p /var/www/domain1.com
mkdir -p /var/www/domain2.com
mkdir -p /var/www/subdomain.domain1.com
mkdir -p /var/www/shared_files
mkdir -p /var/www/shared_files/domain1
mkdir -p /var/www/shared_files/domain2
mkdir -p /var/www/shared_files/subdomain

# تنظیم مجوزها
echo "تنظیم مجوزها..."
chown -R www-data:www-data /var/www/domain1.com
chown -R www-data:www-data /var/www/domain2.com
chown -R www-data:www-data /var/www/subdomain.domain1.com
chown -R www-data:www-data /var/www/shared_files
chmod -R 755 /var/www/domain1.com
chmod -R 755 /var/www/domain2.com
chmod -R 755 /var/www/subdomain.domain1.com
chmod -R 755 /var/www/shared_files
chmod -R 777 /var/www/shared_files/domain1
chmod -R 777 /var/www/shared_files/domain2
chmod -R 777 /var/www/shared_files/subdomain

# کپی فایل‌های کلاینت
echo "کپی فایل‌های کلاینت..."
cp -r clients/domain1/* /var/www/domain1.com/
cp -r clients/domain2/* /var/www/domain2.com/
cp -r clients/subdomain/* /var/www/subdomain.domain1.com/

# کپی فایل‌های API
echo "کپی فایل‌های API..."
cp -r api/* /var/www/api/

# تنظیم مجوزهای API
chown -R www-data:www-data /var/www/api
chmod -R 755 /var/www/api

# کپی پیکربندی Nginx
echo "کپی پیکربندی Nginx..."
cp nginx/domain1.com /etc/nginx/sites-available/
cp nginx/domain2.com /etc/nginx/sites-available/
cp nginx/subdomain.domain1.com /etc/nginx/sites-available/

# فعال‌سازی سایت‌ها
echo "فعال‌سازی سایت‌های Nginx..."
ln -sf /etc/nginx/sites-available/domain1.com /etc/nginx/sites-enabled/
ln -sf /etc/nginx/sites-available/domain2.com /etc/nginx/sites-enabled/
ln -sf /etc/nginx/sites-available/subdomain.domain1.com /etc/nginx/sites-enabled/

# تست پیکربندی Nginx
echo "تست پیکربندی Nginx..."
nginx -t

echo ""
echo "=========================================="
echo "راه‌اندازی با موفقیت انجام شد!"
echo "=========================================="
echo ""
echo "مراحل بعدی:"
echo "1. تنظیم DNS برای دامنه‌ها"
echo "2. اجرای دستور: sudo systemctl restart nginx"
echo "3. دسترسی به کلاینت‌ها از طریق مرورگر"
echo ""

