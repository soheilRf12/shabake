# راهنمای سریع راه‌اندازی

## نصب سریع (5 دقیقه)

```bash
# 1. آپلود فایل‌ها به سرور
scp -r multi-domain-setup user@server:/home/user/

# 2. اتصال به سرور
ssh user@server

# 3. اجرای نصب
cd multi-domain-setup
sudo bash install.sh

# 4. تنظیم DNS (در پنل DNS خود)
# domain1.com → IP سرور
# domain2.com → IP سرور  
# subdomain.domain1.com → IP سرور

# 5. راه‌اندازی مجدد
sudo systemctl restart nginx
```

## استفاده

### 1. دسترسی به کلاینت‌ها
- `http://domain1.com` - کلاینت دامنه 1
- `http://domain2.com` - کلاینت دامنه 2
- `http://subdomain.domain1.com` - کلاینت زیردامنه

### 2. به اشتراک گذاری فایل از زیردامنه به دامنه 2

**در زیردامنه:**
1. فایل را آپلود کنید
2. روی دکمه "اشتراک با Domain2" کلیک کنید

**در دامنه 2:**
1. فایل‌های به اشتراک گذاشته شده در بخش پایین صفحه نمایش داده می‌شوند
2. می‌توانید فایل‌ها را دانلود کنید

## دستورات مفید

```bash
# بررسی وضعیت سرویس‌ها
sudo systemctl status nginx
sudo systemctl status multi-domain-api.service

# راه‌اندازی مجدد
sudo systemctl restart nginx
sudo systemctl restart multi-domain-api.service

# مشاهده لاگ‌ها
sudo tail -f /var/log/nginx/domain1.com.access.log
sudo journalctl -u multi-domain-api.service -f
```

## ساختار دسترسی

```
subdomain.domain1.com → می‌تواند با domain2.com به اشتراک بگذارد ✓
domain1.com → دسترسی به سایر کلاینت‌ها ندارد ✗
domain2.com → دسترسی به سایر کلاینت‌ها ندارد ✗
```

