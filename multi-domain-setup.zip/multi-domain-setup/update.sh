#!/bin/bash

# ============================================
# اسکریپت به‌روزرسانی سیستم
# این اسکریپت فایل‌های کلاینت و API را به‌روزرسانی می‌کند
# ============================================

set -e

# رنگ‌ها
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WWW_DIR="/var/www"

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# بررسی دسترسی root
if [ "$EUID" -ne 0 ]; then 
    echo "لطفاً این اسکریپت را با sudo اجرا کنید"
    exit 1
fi

echo ""
echo -e "${GREEN}==========================================${NC}"
echo -e "${GREEN}به‌روزرسانی سیستم چند دامنه${NC}"
echo -e "${GREEN}==========================================${NC}"
echo ""

# بررسی وجود دایرکتوری پروژه
if [ ! -d "$PROJECT_DIR" ]; then
    echo "خطا: دایرکتوری پروژه پیدا نشد"
    exit 1
fi

# به‌روزرسانی پکیج‌های Python
print_info "به‌روزرسانی پکیج‌های Python..."
if [ -f "$PROJECT_DIR/api/requirements.txt" ]; then
    pip3 install -q -r "$PROJECT_DIR/api/requirements.txt" --upgrade
    print_success "پکیج‌های Python به‌روزرسانی شدند"
else
    print_warning "فایل requirements.txt پیدا نشد"
fi

# کپی فایل‌های کلاینت
print_info "به‌روزرسانی فایل‌های کلاینت..."
if [ -d "$PROJECT_DIR/clients/domain1" ]; then
    cp -r "$PROJECT_DIR/clients/domain1"/* "$WWW_DIR/domain1.com/"
    print_success "فایل‌های domain1.com به‌روزرسانی شدند"
fi

if [ -d "$PROJECT_DIR/clients/domain2" ]; then
    cp -r "$PROJECT_DIR/clients/domain2"/* "$WWW_DIR/domain2.com/"
    print_success "فایل‌های domain2.com به‌روزرسانی شدند"
fi

if [ -d "$PROJECT_DIR/clients/subdomain" ]; then
    cp -r "$PROJECT_DIR/clients/subdomain"/* "$WWW_DIR/subdomain.domain1.com/"
    print_success "فایل‌های subdomain.domain1.com به‌روزرسانی شدند"
fi

# کپی فایل‌های API
print_info "به‌روزرسانی فایل‌های API..."
if [ -d "$PROJECT_DIR/api" ]; then
    cp -r "$PROJECT_DIR/api"/* "$WWW_DIR/api/"
    print_success "فایل‌های API به‌روزرسانی شدند"
fi

# تنظیم مجدد مجوزها
print_info "تنظیم مجدد مجوزها..."
chown -R www-data:www-data "$WWW_DIR/domain1.com"
chown -R www-data:www-data "$WWW_DIR/domain2.com"
chown -R www-data:www-data "$WWW_DIR/subdomain.domain1.com"
chown -R www-data:www-data "$WWW_DIR/api"
chmod -R 755 "$WWW_DIR/domain1.com"
chmod -R 755 "$WWW_DIR/domain2.com"
chmod -R 755 "$WWW_DIR/subdomain.domain1.com"
chmod -R 755 "$WWW_DIR/api"

# راه‌اندازی مجدد سرویس‌ها
print_info "راه‌اندازی مجدد سرویس API..."
systemctl restart multi-domain-api.service
sleep 2

print_info "راه‌اندازی مجدد Nginx..."
systemctl restart nginx

echo ""
print_success "به‌روزرسانی با موفقیت انجام شد!"
echo ""

